/**
 * @return {HTMLElement}
 * @param {string} tagName 
 * @param {object} attribute 
 * @param {HTMLElement | string | Array} content 
 */

function createElement (tagName , attribute , content)
{
    var el = document.createElement(tagName);
    
    for(var key in attribute)
    {
        el.setAttribute(key , attribute[key])
    };

    if (typeof content !== "undefined")
    {
        if( content instanceof HTMLElement)
        {
            el.appendChild(content);
        }else{
            el.innerText = content;
        };
    }
    return el;

}



//*******************************************************card

var cardId = 0;

function creatListItemsCardNode(text)
{
    
    var card = createElement('li',{draggable :true , id : cardId},);
    var cardText = createElement('span',{},text)
    card.appendChild(cardText);
    card.addEventListener('dragstart' , function(event)
    {
        event.dataTransfer.setData('text/plain',event.target.id);
       
        
    });

    cardId++;
  
    var openNaveElement = createElement('a' , {class : 'open-nav'},'...');
    var overlay = createElement('div' , {class : 'overlay hide' , id : 'myNav'},)
    var closeBtn = createElement('a' , {class : 'close-nav'} );
    var closeimgbtn = createElement('img' ,{class : 'close-img-btn' , src : './asset/img/icon-02-512.webp'} )
    var navContent = createElement('div',{class:'nav-content'})
    var editeBtn = createElement('a',{class:'Edit-content-card show'} , 'Edite');
    var inputEdite = createElement('input',{class : 'input-edite-btn hide ' , type : 'text' , placeholder : 'Enter your new namelist'},);
   
    inputEdite.addEventListener('keyup',function(event){
        
        if(event.keyCode === 13){
            inputEdite.focus();  
            card.querySelector('span').innerText = event.target.value;
            overlay.classList.remove('show');
            overlay.classList.add('hide');
            inputEdite.value = 'Enter your new namelist';
           
        }
    })

   
    var deleteBtn = createElement('a' , {class : 'Delete-content-card'} ,'Delete');
    closeBtn.appendChild(closeimgbtn);
    navContent.appendChild (editeBtn);
    navContent.appendChild(inputEdite);
    navContent.appendChild (deleteBtn);
    overlay.appendChild(closeBtn);
    overlay.appendChild(navContent);
    card.appendChild(overlay);
    card.appendChild(openNaveElement);

    openNaveElement.addEventListener('click' , function(){
        overlay.classList.remove('hide');
        overlay.classList.add('show');
    })

    closeBtn.addEventListener('click' , function(){
        overlay.classList.remove('show');
        overlay.classList.add('hide');
    });


    deleteBtn.addEventListener('click' , function(){
        card.classList.remove('show');
        card.classList.add('hide');

    })
    editeBtn.addEventListener('click',function(){
        editeBtn.classList.remove('show');
        editeBtn.classList.add('hide');
        inputEdite.classList.remove('hide');
        inputEdite.classList.add('show');

    })
    




    return card;


};


//***************************************************list
function createListNode(title)
{
    var listTitleElement =  createElement('h4',{class : 'title'},title);

    var listItemElement =  createElement('ul',{class:'task-list'});

    var addCardButtonElement = createElement('button',{class : 'add-card-btn show'} , 'Add a card...');

    var addCardInputElement = createElement('input',{class : 'add-card-input hide' , type : 'text' , placeholder :  'Enter a card name...'} );

    var containerElement = createElement('div' , {class : 'task '});

    


    

    containerElement.appendChild (listTitleElement);
    containerElement.appendChild(listItemElement);
    containerElement.appendChild(addCardButtonElement);
    containerElement.appendChild(addCardInputElement);

    addCardButtonElement.addEventListener('click',function(){

    addCardButtonElement.classList.remove('show');
    addCardButtonElement.classList.add('hide');

    addCardInputElement.classList.remove('hide');
    addCardInputElement.classList.add('show');

    addCardInputElement.focus();

    });
    addCardInputElement.addEventListener('keyup',function(event){
        if(event.keyCode ===13)
        {
        
            var newCard = creatListItemsCardNode(addCardInputElement.value);
            listItemElement.appendChild(newCard);
            addCardInputElement.classList.remove('show');
            addCardInputElement.classList.add('hide');
            addCardInputElement.value = '';
    
            addCardButtonElement.classList.remove('hide');
            addCardButtonElement.classList.add('show');
        }
    })


    console.log(containerElement); 
    listItemElement.addEventListener('drop',function(event){
        event.preventDefault();
        
        var elementId = event.dataTransfer.getData('text/plain');
        listItemElement.appendChild(document.getElementById(elementId));
    })
    listItemElement.addEventListener('dragover',function(event){
        event.preventDefault();
        
    })


    return containerElement;


}

//*************************************************************Add a List  CTA 
function creatAddListCTANode()
{
    var containerElement = createElement('div' , {id :'add-list'});

    var ctaButtonElement = createElement('button' , {class :'add-list-btn show'} ,'Add a list ...');

    var inputCtaElement = createElement('input' , {class :'add-list-input  hide' , type : 'text' , placeholder : 'Enter a listname'} );

    containerElement.appendChild(ctaButtonElement);
    containerElement.appendChild(inputCtaElement);

    ctaButtonElement.addEventListener('click',function(){
    ctaButtonElement.classList.remove('show');
    ctaButtonElement.classList.add('hide');

    inputCtaElement.classList.remove('hide');
    inputCtaElement.classList.add('show');
    inputCtaElement.focus();

    });

    inputCtaElement.addEventListener('keyup',function(event)
    {
        
        if (event.keyCode === 13)
        {
  
            var newList = createListNode(inputCtaElement.value);
            var insertionPosition = document.getElementById('add-list');
            insertionPosition.before(newList);
            inputCtaElement.classList.remove('show');
            inputCtaElement.classList.add('hide');
            inputCtaElement.value = '';
    
            ctaButtonElement.classList.remove('hide');
            ctaButtonElement.classList.add('show');
        }
    });

    return containerElement;

}

var centerContent = document.querySelector('.content');
centerContent.appendChild(creatAddListCTANode());

//*************************************************************Add a List  CTA 