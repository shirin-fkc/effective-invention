(function(){
    window.app = window.app || {};
    window.app.Element = {
        creatListItemsCardNode : creatListItemsCardNode ,
        createListNode : createListNode ,
        creatAddListCTANode : creatAddListCTANode,
        createLink : createLink,
    }

//*****************************************************Create-verlayPage
var overlayPage = document.getElementById('overlay-page');
var overlayBtn = document.getElementById('start');
var overlayInput = document.querySelector('.start-input');
var mainTitle = document.querySelector('#main-title');
overlayBtn.addEventListener('click' , function(event){

    overlayInput.classList.remove('hide');
    overlayInput.classList.add('show');

    overlayBtn.classList.remove('show');
    overlayBtn.classList.add('hide');
});

overlayInput.addEventListener('keyup' , function(event){

    if(event.keyCode === 13){

        overlayInput.focus(); 
        overlayPage.classList.remove('show');
        overlayPage.classList.add('hide');  
        var titleValue = mainTitle.innerText += event.target.value;
        localStorage.setItem('mainTitle' , titleValue);
        var boardPlus = document.querySelector('.board-plus');
        boardPlus.classList.remove('hide');
        boardPlus.classList.add('show');
        boardPlus.innerHTML = localStorage.getItem('mainTitle');
    }

});

//*****************************************************Create-add-board
var board = document.querySelector('.header-board');
var contentBoard = app.helper.createElement('div' , {id : 'content-board' , class : 'hide'});
var addBoaradBtn = app.helper.createElement('a' , {href : 'index.html' ,class : 'add-board-btn' , target : '_self'} , 'Add Board ...');
var addBoardIcon = app.helper.createElement('i' , {class : 'fas fa-plus board-icon'});
var boardPlus = app.helper.createElement('a' , {class :" board-plus hide"} , 'boardName');

board.appendChild(contentBoard);
contentBoard.appendChild(addBoaradBtn);
addBoaradBtn.appendChild(addBoardIcon);
contentBoard.appendChild(boardPlus);

board.addEventListener('click' , function(event){

    contentBoard.classList.remove('hide');
    contentBoard.classList.add('show'); 

});


// ****************************************************Create-sub-menu
 var menu = document.getElementById('show-menu');
 menu.addEventListener('click' , function(event){

    var subMenu = document.getElementById('sub-menu');
    if (subMenu.style.display === "none") {

        subMenu.style.display = "block";
    } else {
        subMenu.style.display = "none";
    };
 });


 var darkColor = document.getElementById('color1');
 var blueColor = document.getElementById('color2');
 var defaultColor = document.getElementById('color3');

 function createLink (href , type){
    var theme = app.helper.createElement('link' , {id : type , rel :'stylesheet' , href :href });
    document.head.appendChild(theme); 
 }
 function deleteAllLinkStyle(){
     var links = document.querySelectorAll('link[rel="stylesheet"][id^="theme-"]');
     for(let i = 0 ; i<links.length ; i++){
        links[i].remove();
     }
 }



 darkColor.addEventListener('click' , function(event){
    deleteAllLinkStyle();
    createLink('./asset/css/dark-theme.css' , 'theme-dark');

 });

 blueColor.addEventListener('click' , function(event){
    deleteAllLinkStyle();
    createLink('./asset/css/blue-theme.css' , 'theme-blue'); 
 });

 defaultColor.addEventListener('click' , function(event){
    deleteAllLinkStyle();
    createLink('./asset/css/style.css' , 'theme-default');
 });

//*******************************************************Create-card

var cardId = 0;

function creatListItemsCardNode(text)
{
    
    var card = app.helper.createElement('li',{draggable :true , id : cardId  , class : 'card'},);

    var cardText = app.helper.createElement('span',{},text);

    card.appendChild(cardText);

    card.addEventListener('dragstart' , function(event)
    {
        event.dataTransfer.setData('text/plain',event.target.id);
    });
    
    card.addEventListener('dragenter' , function(event){

        event.preventDefault();
        this.style.backgroundColor = 'rgba(0 , 0 , 0 ,0.2)';
        this.style.transform = 'translateY(-10px)';
    }); 

    card.addEventListener('dragleave' , function(event){
        this.style.backgroundColor = '#ffffff91';
    });

    card.addEventListener('dragover' , function(event){
        event.preventDefault();
        this.style.transform = 'translateY(-10px)';
    })
    card.addEventListener('drop' , function(event){
        event.preventDefault();
        this.style.backgroundColor = '#ffffff91';
        if(card.id % 2 !== 0 ){
            card.style.backgroundColor = '#00000013';
        }
    });

    
    cardId++;
  
    var openNaveElement = app.helper.createElement('a' , {class : 'open-nav'});
    var iconOpenNav = app.helper.createElement('i' , {class : 'fas fa-caret-down open-nav-btn'})
    var overlay = app.helper.createElement('div' , {class : 'overlay hide' , id : 'myNav'},)
    var closeBtn = app.helper.createElement('a' , {class : 'close-nav'} );
    var closeimgbtn = app.helper.createElement('img' ,{class : 'close-img-btn' , src : './asset/img/icon-02-512.webp'} )
    var navContent = app.helper.createElement('div',{class:'nav-content'})
    var editeBtn = app.helper.createElement('a',{class:'Edit-content-card show'} , 'Edite');
    var iconEditeBtn = app.helper.createElement('i' , {class : 'fas fa-edit icone' });
    var deleteBtn = app.helper.createElement('a' , {class : 'Delete-content-card'} ,'Delete');
    var iconDeleteBtn = app.helper.createElement('i' , { class :'fas fa-backspace icone'});
    var inputEdite = app.helper.createElement('input',{class : 'input-edite-btn hide ' , type : 'text' , placeholder : 'Enter your new namelist'},);
    // var openSubList = app.helper.createElement('a' , {class : 'open-sub-list show'} ,'make new list of this card' );
    // var subListInput = app.helper.createElement('input',{class : 'input-sub-list hide ' , type : 'text' , placeholder : 'Enter your Sublist Name'});
    // var subListContent = app.helper.createElement('div' , {class : 'sub-list-content hide'} , 'dfbunsrildk');
    inputEdite.addEventListener('keyup',function(event){
        
        if(event.keyCode === 13){
            inputEdite.focus();  
            card.querySelector('span').innerText = event.target.value;
            overlay.classList.remove('show');
            overlay.classList.add('hide');
            editeBtn.classList.remove('hide'); 
            editeBtn.classList.add('show');
            inputEdite.classList.remove('show');
            inputEdite.classList.add('hide');
           
        }
    })

    openNaveElement.appendChild(iconOpenNav);
    closeBtn.appendChild(closeimgbtn);
    navContent.appendChild (editeBtn);
    editeBtn.appendChild(iconEditeBtn);
    navContent.appendChild(inputEdite);
    navContent.appendChild (deleteBtn);
    // navContent.appendChild(openSubList);
    // navContent.appendChild(subListInput);
    deleteBtn.appendChild(iconDeleteBtn);
    overlay.appendChild(closeBtn);
    overlay.appendChild(navContent);
    card.appendChild(overlay);
    card.appendChild(openNaveElement);

    openNaveElement.addEventListener('click' , function(){
        overlay.classList.remove('hide');
        overlay.classList.add('show');
    })

    closeBtn.addEventListener('click' , function(){
        overlay.classList.remove('show');
        overlay.classList.add('hide');
    });


    deleteBtn.addEventListener('click' , function(){
        card.classList.remove('show');
        card.classList.add('hide');

    })
    editeBtn.addEventListener('click',function(){
        editeBtn.classList.remove('show');
        editeBtn.classList.add('hide');
        inputEdite.classList.remove('hide');
        inputEdite.classList.add('show');

    })
    // openSubList.addEventListener('click' , function(){
    //     subListInput.classList.remove('hide');
    //     subListInput.classList.add('show');
    //     openSubList.classList.remove('show');
    //     openSubList.classList.add('hide');
    //     subListInput.focus();
    // })
    // subListInput.addEventListener('keyup' , function(event){

    //     if(event.keyCode ===13){
    //         openSubList.classList.remove('show');
    //         openSubList.classList.add('hide');
    //         const card = document.querySelector('.task-list');
    //         card.appendChild(subListContent);
    //         subListContent.classList.add('show');
    //         subListContent.classList.remove('hide');
    //         overlay.classList.remove('show');
    //         overlay.classList.add('hide');
    //     }
    // })




    return card;


};


//***************************************************Create-list
function createListNode(title)
{
    var listTitleElement =  app.helper.createElement('h4',{class : 'title'},title);
    var listItemElement =  app.helper.createElement('ul',{class:'task-list'});
    var addCardButtonElement = app.helper.createElement('button',{class : 'add-card-btn show'} , 'Add a card...');
    var addCardInputElement = app.helper.createElement('input',{class : 'add-card-input hide' , type : 'text' , placeholder :  'Enter a card name...'} );
    var containerElement = app.helper.createElement('div' , {class : 'task '});
    var dropZoneCard = app.helper.createElement('a' , {href : '#' , id : 'dropCard' , class : 'hide'} , 'drop card here/or no click to remove box')
    var overlayList = app.helper.createElement('div' , {class : 'overlay-list hide' , id :'navListOverlay' });
    var closeOverlayList = app.helper.createElement('a' , {href : '#' , class : 'close-overlay'});
    var colseOverlayImg = app.helper.createElement('img' , {src : './asset/img/icon-02-512.webp' , class : 'close-imgList-btn'});
    var overlayContent = app.helper.createElement('div' , {class : 'overlay-content '});
    var editeListBtn = app.helper.createElement('a',{href : '#' , class:'Edit-content-list show'} , 'Edite');
    var iconEditeListBtn = app.helper.createElement('i' , {class : 'fas fa-edit icone' });
    var deleteListBtn = app.helper.createElement('a' , {href : '#' , class : 'Delete-content-list'} ,'Delete');
    var iconDeleteLIstBtn = app.helper.createElement('i' , { class :'fas fa-backspace icone'});
    var inputListEdite = app.helper.createElement('input',{class : 'input-editeList-btn hide ' , type : 'text' , placeholder : 'Enter your new namelist'});
    var linkOpenList = app.helper.createElement('a' , {href : '#' , id : 'link-open-list'});
    var openListIcon = app.helper.createElement('i' , { class : 'far fa-caret-square-down open-list-icon'});
    

   
    containerElement.appendChild(linkOpenList);
    linkOpenList.appendChild(openListIcon);
    containerElement.appendChild(overlayList);
    overlayList.appendChild(closeOverlayList);
    closeOverlayList.appendChild(colseOverlayImg);
    overlayList.appendChild(overlayContent);
    overlayContent.appendChild(editeListBtn);
    editeListBtn.appendChild(iconEditeListBtn);
    overlayList.appendChild(inputListEdite);
    overlayContent.appendChild(deleteListBtn);
    deleteListBtn.appendChild(iconDeleteLIstBtn);
    containerElement.appendChild (listTitleElement);
    containerElement.appendChild(listItemElement);
    listItemElement.appendChild(dropZoneCard);
    containerElement.appendChild(addCardButtonElement);
    containerElement.appendChild(addCardInputElement);

    linkOpenList.addEventListener('click' , function (event){
        
        overlayList.classList.remove('hide');
        overlayList.classList.add('show');
    });
    closeOverlayList.addEventListener('click' , function(){
        overlayList.classList.remove('show');
        overlayList.classList.add('hide');
    });


    deleteListBtn.addEventListener('click' , function(){
        containerElement.classList.remove('show');
        containerElement.classList.add('hide');

    });
    editeListBtn.addEventListener('click',function(){
        editeListBtn.classList.remove('show');
        editeListBtn.classList.add('hide');
        inputListEdite.classList.remove('hide');
        inputListEdite.classList.add('show');

    });

    
    inputListEdite.addEventListener('keyup',function(event){
        
        if(event.keyCode === 13){
            inputListEdite.focus();  
            containerElement.querySelector('.title').innerText = event.target.value;
            overlayList.classList.remove('show');
            overlayList.classList.add('hide');
            editeListBtn.classList.remove('hide'); 
            editeListBtn.classList.add('show');
            inputListEdite.classList.remove('show');
            inputListEdite.classList.add('hide');
        }
    })
    


    addCardButtonElement.addEventListener('click',function(){

    addCardButtonElement.classList.remove('show');
    addCardButtonElement.classList.add('hide');

    addCardInputElement.classList.remove('hide');
    addCardInputElement.classList.add('show');

    addCardInputElement.focus();

    });

    addCardInputElement.addEventListener('keyup',function(event){
        if(event.keyCode ===13)
        {
        
            var newCard = creatListItemsCardNode(addCardInputElement.value);
            listItemElement.appendChild(newCard);
            addCardInputElement.classList.remove('show');
            addCardInputElement.classList.add('hide');
            addCardInputElement.value = '';
    
            addCardButtonElement.classList.remove('hide');
            addCardButtonElement.classList.add('show');
        }
    })


    console.log(containerElement);
    listItemElement.addEventListener('dragover',function(event){
        event.preventDefault();
    });

    listItemElement.addEventListener('drop',function(event){

        event.preventDefault();
        var elementId = event.dataTransfer.getData('text/plain');
        listItemElement.appendChild(document.getElementById(elementId));
    });

    return containerElement;


}

//*************************************************************Create-Add a List  CTA 
function creatAddListCTANode()
{
    var containerElement = app.helper.createElement('div' , {id :'add-list'});

    var ctaButtonElement = app.helper.createElement('button' , {class :'add-list-btn show'} ,'Add a list ...');

    var inputCtaElement = app.helper.createElement('input' , {class :'add-list-input  hide' , type : 'text' , placeholder : 'Enter a listname'} );

    containerElement.appendChild(ctaButtonElement);
    containerElement.appendChild(inputCtaElement);

    ctaButtonElement.addEventListener('click',function(){
    ctaButtonElement.classList.remove('show');
    ctaButtonElement.classList.add('hide');

    inputCtaElement.classList.remove('hide');
    inputCtaElement.classList.add('show');
    inputCtaElement.focus();

    });

    inputCtaElement.addEventListener('keyup',function(event)
    {
        
        if (event.keyCode === 13)
        {
  
            var newList = createListNode(inputCtaElement.value);
            var insertionPosition = document.getElementById('add-list');
            insertionPosition.before(newList);
            inputCtaElement.classList.remove('show');
            inputCtaElement.classList.add('hide');
            inputCtaElement.value = '';
    
            ctaButtonElement.classList.remove('hide');
            ctaButtonElement.classList.add('show');
        }
    });

    return containerElement;

}

var centerContent = document.querySelector('.content');
centerContent.appendChild(creatAddListCTANode());

//*************************************************************//
})();